<?php
include('db.php');

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);

    if ($quantity > 0) {
        $check_stock = $conn->query("SELECT current_stock FROM products WHERE id = $product_id");
        
        if ($check_stock && $check_stock->num_rows > 0) {
            $product = $check_stock->fetch_assoc();
            
            if ($product['current_stock'] < $quantity) {
                $message = "<div style='color:red; font-weight:bold;'>Error: Hindi sapat ang stock!</div>";
            } else {
                $conn->begin_transaction();

                try {
                    $sql_update = "UPDATE products SET current_stock = current_stock - $quantity WHERE id = $product_id";
                    $conn->query($sql_update);

                    $sql_log = "INSERT INTO inventory_logs (product_id, transaction_type, quantity) VALUES ($product_id, 'OUT', $quantity)";
                    $conn->query($sql_log);

                    $conn->commit();
                    $message = "<div style='color:green; font-weight:bold;'>Matagumpay na nabawas ang stock!</div>";
                } catch (Exception $e) {
                    $conn->rollback();
                    $message = "<div style='color:red; font-weight:bold;'>May nagka-error sa pag-save.</div>";
                }
            }
        } else {
            $message = "<div style='color:red; font-weight:bold;'>Error: Hindi nahanap ang produkto.</div>";
        }
    } else {
        $message = "<div style='color:red; font-weight:bold;'>Error: Dapat mas mataas sa 0 ang quantity.</div>";
    }
}

$products_list = $conn->query("SELECT id, product_name, current_stock FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock-Out Form</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f4f4f9; }
        .container { max-width: 450px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { font-weight: bold; display: block; margin-bottom: 5px; }
        select, input[type="number"], button { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { background-color: #dc3545; color: white; border: none; font-size: 16px; cursor: pointer; }
        button:hover { background-color: #c82333; }
        .message-box { margin-bottom: 15px; }
    </style>
</head>
<body>

<div class="container">
    <h2>Stock-Out (Lumabas na Stock)</h2>
    
    <div class="message-box">
        <?php echo $message; ?>
    </div>

    <form action="" method="POST">
        <div class="form-group">
            <label for="product_id">Piliin ang Produkto:</label>
            <select name="product_id" id="product_id" required>
                <option value="">-- Pumili ng Produkto --</option>
                <?php if ($products_list && $products_list->num_rows > 0): ?>
                    <?php while($row = $products_list->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>">
                            <?php echo htmlspecialchars($row['product_name']) . " (Stock: " . $row['current_stock'] . ")"; ?>
                        </option>
                    <?php endwhile; ?>
                <?php endif; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="quantity">Dami ng Ibabaon / Ilalabas (Quantity):</label>
            <input type="number" name="quantity" id="quantity" min="1" required>
        </div>

        <button type="submit">I-save ang Stock-Out</button>
    </form>
</div>

</body>
</html>
